Contributors
================================================================================

Marek Srejma - https://github.com/Sammyboy - sam@gmx-topmail.de

- Ideas for limit and toPlaceholder parameter
- Code for sorting the output

Danilo Cuculić - https://github.com/Eoler

- Idea for tplConfig parameter
- Some Output enhancements
- Better ManagerManager fix (fixed MODX 1.0.9)

Cipa - https://github.com/Cipa

- Bugfixes for MODX installations not in webroot

Jukka Hankaniemi - https://github.com/BlowbackDesign

- Finnish language

Dmytro Lukianenko - https://github.com/dmi3yy – dmi3yy@gmail.com

- Russian language

Salvatore Tedde - https://github.com/microcipcip - info@jertix.org

- Better styling of the editing layer

Vitor - https://github.com/vmoreira

- Portuguese language

falkon - https://github.com/falkon

- Bugfix

Bruno Perner - https://github.com/Bruno17 - info@webcmsolutions.de

- Ditto customsort extender

And a lot of testers ...
