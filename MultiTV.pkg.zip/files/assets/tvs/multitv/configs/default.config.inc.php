<?php
$settings['display'] = 'vertical';
$settings['fields'] = array(
	'key' => array(
		'caption' => 'Key',
		'type' => 'text'
	),
	'value' => array(
		'caption' => 'Value',
		'type' => 'text'
		));
?>
