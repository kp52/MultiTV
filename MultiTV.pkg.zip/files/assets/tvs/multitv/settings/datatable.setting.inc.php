<?php
$settings['css'] = array(
	'[+tvpath+]css/colorbox.css',
	'[+tvpath+]css/dataTables.css',
	'[+tvpath+]css/easytabs.css',
	'[+tvpath+]css/contextMenu.css'
);
$settings['scripts'] = array(
	'[+tvpath+]js/jquery-colorbox-1.3.19.3-min.js',
	'[+tvpath+]js/jquery-dataTables-1.9.4.min.js',
	'[+tvpath+]js/jquery-easytabs-3.1.1.min.js',
	'[+tvpath+]js/jquery-dataTables.rowReordering-1.0.0.js',
	'[+tvpath+]js/jquery-contextMenu-1.7.js'
);
?>
