<?php
$settings['css'] = array(
	'[+tvpath+]css/jquery-ui-1.8.24.custom.css',
	'[+tvpath+]css/multitv.css'
);
$settings['scripts'] = array(
	'[+tvpath+]js/jquery-1.4.4.min.js',
	'[+tvpath+]js/jquery-json-2.3.min.js',
	'[+tvpath+]js/jquery-ui-1.8.24.custom.min.js',
	'[+tvpath+]js/jquery-ui-timepicker-addon.js',
	'[+tvpath+]js/jquery-field-0.9.6.min.js'
);
?>
