<?php
$settings['css'] = array(
	'[+tvpath+]css/colorbox.css'
);
$settings['scripts'] = array(
	'[+tvpath+]js/jquery-colorbox-1.3.19.3-min.js',
	'[+tvpath+]js/jquery-htmlClean-1.3.0.min.js'
);
?>
