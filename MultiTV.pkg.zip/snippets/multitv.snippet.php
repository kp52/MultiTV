<?php
/**
 * multiTV
 * 
 * Transform template variables into a sortable multi item list.
 
 * @category 	snippet
 * @version 	1.5.2
 * @license 	http://www.gnu.org/copyleft/gpl.html GNU Public License (GPL)
 * @author		Jako (thomas.jakobi@partout.info)
 */
return include(MODX_BASE_PATH.'assets/tvs/multitv/multitv.snippet.php');

