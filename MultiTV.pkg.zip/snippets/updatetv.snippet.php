<?php
/**
 * updateTV
 *
 * Transform template variables into a sortable multi item list.
 *
 * @category 	snippet
 * @version 	clipper-1.6
 * @license 	http://www.gnu.org/copyleft/gpl.html GNU Public License (GPL)
 * @author		Jako to version 1.5.2 and now the ClipperCMS community
 */
return include(MODX_BASE_PATH.'assets/tvs/multitv/updatetv.snippet.php');

